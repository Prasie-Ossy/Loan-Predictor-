import streamlit as st
import pandas as pd
import pickle 

# load the model
with open("loan_predictor.pkl" ,'rb') as f:
    model = pickle.load(f) 

# streamlit App
st.title('Loan Predictor App')
        
st.write('Enter your details to check loan approval chances')

# Valid items
valid_loannumbers = [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 
                     19, 20, 22, 23, 27]
valid_loanamounts = [30000., 20000., 10000., 40000., 25000., 15000., 50000., 35000.,
                    60000.]
valid_termdays = [15, 30, 60, 90]
valid_prev_loanamounts = [3000, 4000, 5000, 6000, 7000, 8000, 9000, 10000, 15000, 
                          20000, 25000, 30000, 35000, 40000, 50000, 60000]
valid_Banktypes = ["Savings", "Current", "Other"]
valid_Bankname = ['Diamond Bank', 'EcoBank', 'First Bank', 'GT Bank', 'Access Bank',
       'UBA', 'Union Bank', 'FCMB', 'Zenith Bank', 'Stanbic IBTC',
       'Fidelity Bank', 'Wema Bank', 'Sterling Bank', 'Skye Bank',
       'Keystone Bank', 'Heritage Bank', 'Unity Bank',
       'Standard Chartered']
valid_employment = ['Permanent', 'Unemployed', 'Self-Employed', 'Student', 'Retired',
       'Contract']
valid_Educvation = ['Post-Graduate', 'Graduate', 'Primary', 'Secondary']

# Mapping of loanamount to valid totaldue values 
loan_to_totaldue = {
    10000: [11500, 12250, 12500, 13000, 10750, 11000, 11125, 10250, 10500],
    15000: [17250, 18375, 15750, 16500],
    20000: [22250, 23000, 22000, 21500, 20500, 21000],
    25000: [28750, 27500],
    30000: [34500, 33000, 31500],
    35000: [39000, 38500,38500.2],
    40000: [44000, 42000, 43500],
    50000: [52500, 55000, 57500,57000.5],
    60000: [68100, 65400, 62700]
}

# Mapping of prev_loanamount to valid prev_totaldue values (replace with df_merged output)
prev_loan_to_totaldue = {
    3000: [3900,34500, 5200],
    4000: [4600],
    5000: [5750, 6125],
    6000: [6900, 7800, 6125],
    7000: [8050],
    8000: [9200],
    9000: [10350, 10625],
    10000: [11500, 13000, 11125, 12250, 11000, 10750, 11400, 11450, 11700, 11750],
    15000: [17250, 18375, 15750, 16500, 16600, 16675, 16125],
    20000: [22250, 23000, 22000, 21500, 20500, 21000, 21750, 21800, 21700],
    25000: [28750, 27500, 26250, 26875],
    30000: [34500, 33000, 31500, 33900, 34100],
    35000: [39000, 38500, 39450, 36200],
    40000: [44000, 42000, 43500, 44800, 47600, 47100, 41900],
    50000: [52500, 55000, 57500, 47500],
    60000: [68100, 62700]
}

# collect information from user 
loannumber = st.selectbox("Loan Number", valid_loannumbers)
loanamount = st.selectbox("Loan Amount ($)", valid_loanamounts)
termdays = st.selectbox("Term (Days)", valid_termdays)
totaldue = st.selectbox("Total Due ($)", loan_to_totaldue.get(loanamount, [6000.0]))
prev_loanamount = st.selectbox("Previous Loan Amount ($)", valid_prev_loanamounts)
prev_totaldue = st.selectbox("Previous Total Due ($)", prev_loan_to_totaldue.get(prev_loanamount, [0.0]))
prev_termdays = st.selectbox("Previous Term (Days)", valid_termdays)
age = st.number_input('Age',29,63,30)
prev_loan_paid_days = st.number_input("Previous Loan Paid (Days)",1,400,1)
bank_account_type = st.selectbox("Bank Account Type", valid_Banktypes)  
bank_name_clients = st.selectbox("Bank Name", valid_Bankname) 
employment_status_clients = st.selectbox("Employment Status", valid_employment)
level_of_education_clients = st.selectbox("Education Level", valid_Educvation)

# compute and display 
diff_days = prev_termdays - prev_loan_paid_days
st.write(f"Difference in Days: {diff_days}")
    
if diff_days >= 1:
    payment_score = "Low"
elif diff_days == 0:
    payment_score = "Medium"
elif diff_days <= -1:
    payment_score = "High"
else:
    payment_score = "Error"
st.write(f"Payment Score: {payment_score}")
    
if loanamount <= 10000:
    risk_band = "Low"
elif loanamount <= 30000:
    risk_band = "Medium"
elif loanamount > 30000:
    risk_band = "High"
else:
    risk_band = "Error"
st.write(f"Risk Band: {risk_band}")

# Predict button 
if st.button('How are my loan chances?'):
    data = pd.DataFrame({
            "loannumber": [loannumber],
            "loanamount": [loanamount],
            "termdays": [termdays],
            "totaldue": [totaldue],
            "prev_loanamount": [prev_loanamount],
            "prev_totaldue": [prev_totaldue],
            "prev_termdays": [prev_termdays],
            "age": [age],
            "prev_loan_paid_days": [prev_loan_paid_days],
            "diff_days": [diff_days],
            "payment_score": [payment_score],
            "bank_account_type": [bank_account_type],
            "bank_name_clients": [bank_name_clients],
            "employment_status_clients": [employment_status_clients],
            "level_of_education_clients": [level_of_education_clients],
            "risk_band": [risk_band]
        })
    
    # convert into a dataframe
    input_df = pd.DataFrame(data)
    
    # predict model
    prediction = model.predict(input_df)[0]
    probability = model.predict_proba(input_df)[0, 1]
    result = "Good (Approved)" if prediction == 1 else "Bad (Not Approved)"
    
    # Display
    st.success(f"Prediction: {result}")
    